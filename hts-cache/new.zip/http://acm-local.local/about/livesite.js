<!DOCTYPE html>
<html lang="en-US"	class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js-priorityNav wf-robotocondensed-n7-active wf-robotocondensed-n4-active wf-robotocondensed-n3-active wf-robotocondensed-i3-active wf-robotocondensed-i4-active wf-robotocondensed-i7-active wf-roboto-n4-active wf-roboto-n5-active wf-active">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<link rel="shortcut icon" href="/favicon.ico?v=2">
	<meta class="foundation-data-attribute-namespace">
	<meta class="foundation-mq-xxlarge">
	<meta class="foundation-mq-xlarge-only">
	<meta class="foundation-mq-xlarge">
	<meta class="foundation-mq-large-only">
	<meta class="foundation-mq-large">
	<meta class="foundation-mq-medium-only">
	<meta class="foundation-mq-medium">
	<meta class="foundation-mq-small-only">
	<meta class="foundation-mq-small">
	<meta class="foundation-mq-topbar">
	<title>ACM | Page not found - acm-local</title>
	<style type="text/css">.wpfts-result-item .wpfts-smart-excerpt {}.wpfts-result-item .wpfts-smart-excerpt b {font-weight:bold !important;}.wpfts-result-item .wpfts-not-found {color:#808080;font-size:0.9em;}.wpfts-result-item .wpfts-score {color:#006621;font-size:0.9em;}.wpfts-shift {margin-left:40px;}.wpfts-result-item .wpfts-download-link {color:#006621;font-size:0.9em;}.wpfts-result-item .wpfts-file-size {color:#006621;font-size:0.9em;}.wpfts-result-item .wpfts-sentence-link {text-decoration:none;cursor:pointer;color:unset;}.wpfts-result-item .wpfts-sentence-link:hover {text-decoration:underline;color:inherit;}.wpfts-result-item .wpfts-word-link {text-decoration:none;cursor:pointer;}.wpfts-result-item .wpfts-word-link:hover {text-decoration:underline;}wpfts-highlight.wpfts-highlight-sentence {background-color:rgba(255, 255, 128, 0.5) !important;display:inline-block;}wpfts-highlight.wpfts-highlight-word {background-color:rgba(255, 128, 128, 0.5) !important;display:inline-block;}</style><meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v27.7 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - acm-local" />
	<meta property="og:site_name" content="acm-local" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"http:\/\/acm-local.local\/#website","url":"http:\/\/acm-local.local\/","name":"acm-local","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"http:\/\/acm-local.local\/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//unpkg.com' />
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id="wp-block-library-inline-css">
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}:root .has-text-align-center{text-align:center}:root .has-text-align-left{text-align:left}:root .has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{word-wrap:normal!important;border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-color]){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=/wp-includes/css/dist/block-library/common.min.css */
</style>
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>

<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='wpfts_jquery-ui-styles-css' href='http://acm-local.local/wp-content/plugins/fulltext-search/style/wpfts_autocomplete.css?ver=1.80.280' media='all' />
<link rel='stylesheet' id='acm-style-css' href='http://acm-local.local/wp-content/themes/acm/style.css?ver=1781032743' media='all' />
<link rel='stylesheet' id='acm-animations-css' href='http://acm-local.local/wp-content/themes/acm/css/animations.css?ver=1.0.0' media='all' />
<script id="jquery-core-js" src="http://acm-local.local/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="http://acm-local.local/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="jquery-ui-core-js" src="http://acm-local.local/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3"></script>
<script id="jquery-ui-menu-js" src="http://acm-local.local/wp-includes/js/jquery/ui/menu.min.js?ver=1.13.3"></script>
<script id="wp-dom-ready-js" src="http://acm-local.local/wp-includes/js/dist/dom-ready.min.js?ver=a06281ae5cf5500e9317"></script>
<script id="wp-hooks-js" src="http://acm-local.local/wp-includes/js/dist/hooks.min.js?ver=7496969728ca0f95732d"></script>
<script id="wp-i18n-js" src="http://acm-local.local/wp-includes/js/dist/i18n.min.js?ver=781d11515ad3d91786ec"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="wp-a11y-js" src="http://acm-local.local/wp-includes/js/dist/a11y.min.js?ver=af934e5259bc51b8718e"></script>
<script id="jquery-ui-autocomplete-js" src="http://acm-local.local/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.13.3"></script>
<script id="wpfts_frontend-js" src="http://acm-local.local/wp-content/plugins/fulltext-search/js/wpfts_frontend.js?ver=1.80.280"></script>
<link rel="https://api.w.org/" href="http://acm-local.local/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://acm-local.local/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.0" />
<script type="text/javascript">
		document.wpfts_ajaxurl = "http://acm-local.local/wp-admin/admin-ajax.php";
	</script>              <style>#livesite_active_engage .ls-more-actions-C {display: none}</style>
            <script type="text/javascript">
        var vcUrl = 'www.vcita.com/widgets/active_engage/wordpress.demo/loader.js?format=js';
        var script = document.createElement('script');
        script.src = '//' + vcUrl;
        script.type = 'text/javascript';

        document.addEventListener('DOMContentLoaded', () => {
          const scripts = document.querySelectorAll('script[src]');
          let sfound = false;

          for (let i = 0; i < scripts.length; i++) {
            if ((scripts[i].getAttribute('src').indexOf('vcita.com') >= 0 &&
              scripts[i].getAttribute('src').indexOf('livesite.js') >= 0) ||
              (scripts[i].getAttribute('src').indexOf('vcita.com') >= 0 &&
                scripts[i].getAttribute('src').indexOf('loader.js') >= 0)
            ) {
              sfound = true;
              break
            }
          }

          if (sfound) return;

                    document.cookie = "livesite_<br />
<b>Warning</b>:  Undefined array key "uid" in <b>C:\Users\navne\Local Sites\acm-local\app\public\wp-content\plugins\meeting-scheduler-by-vcita\vcita-widgets-functions.php</b> on line <b>45</b><br />
_engage=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          
          
            			          window.Vcita = {};
			Vcita.legacyOptions = function () {
            return {
              desktopEnabled: 1,
              mobileEnabled: 1,
              engageButton: true,
              activeEngage: true,
              engageState: 'closed',
              actionButtons: false,
              // inlineActions: false,
              activeEngageAction: "schedule",
              //mobileQuickAction: "schedule",
              activeEngageActionText: 'Schedule now',
              engageButtonText: 'Schedule now',
              activeEngageTitle: "Let's talk!",
              activeEngageText: "Thanks for stopping by! We're here to help…",
                          imageUrl: "",
                          textPoweredBy: 'Powered by vcita',
              themeActionColor: '#01dcf7',
              themeActionHover: '#01dcf7',
              themeActionText: '#ffffff',
              themeMainActionColor: '#01dcf7',
              themeMainActionHover: '#01dcf7',
              themeMainActionText: '#ffffff'
			  }
          };
                        

                  const checkLivesite = () => {
            if (!window.LiveSite) return false;
              // console.log(window.Vcita.legacyOptions());
              // console.log(window.LiveSite);
            return true;
          };
                    const checkEngageButton = () => {
            const leb = document.querySelector('#livesite_engage_button a.ls-engage-button');

            if (leb != null) {
                            leb.classList.remove('livesite-engage');
              leb.classList.add('livesite-schedule');
              // leb.onclick = LiveSite.schedule;
              return true;
            } else return false;
          };

          let tryit = 0, aeint;

          let lint = setInterval(() => {
            if (checkLivesite() || tryit == 100000) {
              clearInterval(lint);
              tryit = 0;

              aeint = setInterval(() => {
                if (checkEngageButton() || tryit == 100000) {
                  clearInterval(aeint);
                } else tryit++;
              }, 10);
            } else tryit++;
          }, 100);
                  
          document.body.appendChild(script)
        });
      </script>
    <meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="http://acm-local.local"><link rel="alternate" href="http://acm-local.local/wp-json/tribe/events/v1/" /><link rel="shortcut icon" href="http://acm-local.local/wp-content/themes/acm/favicon.ico" type="image/x-icon" />	<style>
		blockquote, dd, div, dl, dt, form, h1, h2, h3, h4, h5, h6, li, ol, p, pre, td, th, ul {
			margin: 0;
			padding: 0;
		}
		.subheader, code, p {
			font-weight: 400;
		}
		.tooltip, p {
			font-size: .875rem;
		}
		.breadcrumbs a, p {
			font-family: Verdana;
		}
		* {
			box-sizing: border-box;
		}
		p {
			line-height: 1.4;
			margin-bottom: 1.25rem;
			display: block;
			margin-block-start: 1em;
			margin-block-end: 1em;
			margin-inline-start: 0px;
			margin-inline-end: 0px;
			unicode-bidi: isolate;
		}
		body {
			background: #f5f5f5;
			color: #222;
			padding: 0;
			margin: 0;
			font-family: Verdana, Geneva, Tahoma, sans-serif;
			line-height: 1.5;
			cursor: auto;
		}
		body, html {
			font-size: 100%;
			height: 100%;
		}
		.alert-box, a:after, body, .antialiased {
			-webkit-font-smoothing: antialiased;
		}
		a:after, body {
			font-style: normal;
		}
		html {
			font-family: sans-serif;
			-ms-text-size-adjust: 100%;
			-webkit-text-size-adjust: 100%;
			-webkit-tap-highlight-color: transparent;
		}
		:after, :before {
			box-sizing: border-box;
		}
		:root {
			--wp--preset--aspect-ratio--square: 1;
			--wp--preset--aspect-ratio--4-3: 4 / 3;
			--wp--preset--aspect-ratio--3-4: 3 / 4;
			--wp--preset--aspect-ratio--3-2: 3 / 2;
			--wp--preset--aspect-ratio--2-3: 2 / 3;
			--wp--preset--aspect-ratio--16-9: 16 / 9;
			--wp--preset--aspect-ratio--9-16: 9 / 16;
			--wp--preset--color--black: #000000;
			--wp--preset--color--cyan-bluish-gray: #abb8c3;
			--wp--preset--color--white: #ffffff;
			--wp--preset--color--pale-pink: #f78da7;
			--wp--preset--color--vivid-red: #cf2e2e;
			--wp--preset--color--luminous-vivid-orange: #ff6900;
			--wp--preset--color--luminous-vivid-amber: #fcb900;
			--wp--preset--color--light-green-cyan: #7bdcb5;
			--wp--preset--color--vivid-green-cyan: #00d084;
			--wp--preset--color--pale-cyan-blue: #8ed1fc;
			--wp--preset--color--vivid-cyan-blue: #0693e3;
			--wp--preset--color--vivid-purple: #9b51e0;
			--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgb(6, 147, 227) 0%, rgb(155, 81, 224) 100%);
			--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
			--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgb(252, 185, 0) 0%, rgb(255, 105, 0) 100%);
			--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgb(255, 105, 0) 0%, rgb(207, 46, 46) 100%);
			--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
			--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
			--wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
			--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
			--wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
			--wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
			--wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
			--wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
			--wp--preset--font-size--small: 13px;
			--wp--preset--font-size--medium: 20px;
			--wp--preset--font-size--large: 36px;
			--wp--preset--font-size--x-large: 42px;
			--wp--preset--spacing--20: 0.44rem;
			--wp--preset--spacing--30: 0.67rem;
			--wp--preset--spacing--40: 1rem;
			--wp--preset--spacing--50: 1.5rem;
			--wp--preset--spacing--60: 2.25rem;
			--wp--preset--spacing--70: 3.38rem;
			--wp--preset--spacing--80: 5.06rem;
			--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
			--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);
			--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);
			--wp--preset--font-size--normal: 16px;
			--wp--preset--font-size--huge: 42px;
			--wp-block-synced-color: #7a00df;
			--wp-block-synced-color--rgb: 122, 0, 223;
			--wp-bound-block-color: var(--wp-block-synced-color);
			--wp-editor-canvas-background: #ddd;
			--wp-admin-theme-color: #007cba;
			--wp-admin-theme-color--rgb: 0, 124, 186;
			--wp-admin-theme-color-darker-10: #006ba1;
			--wp-admin-theme-color-darker-10--rgb: 0, 107, 160.5;
			--wp-admin-theme-color-darker-20: #005a87;
			--wp-admin-theme-color-darker-20--rgb: 0, 90, 135;
			--wp-admin-border-width-focus: 2px;
		}
		@media (min-resolution: 192dpi) {
			:root {
				--wp-admin-border-width-focus: 1.5px;
			}
		}

		/* Timeline Scroll Animations */
		@keyframes timelineFadeInUp {
			from {
				opacity: 0;
				transform: translateY(40px);
			}
			to {
				opacity: 1;
				transform: translateY(0);
			}
		}

		@keyframes timelineFadeOutDown {
			from {
				opacity: 1;
				transform: translateY(0);
			}
			to {
				opacity: 0;
				transform: translateY(40px);
			}
		}

		.timeline-item {
			opacity: 0;
			transform: translateY(40px);
			transition: opacity 0.6s cubic-bezier(0.22, 1, 0.36, 1), transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
		}

		.timeline-item.is-visible {
			opacity: 1;
			transform: translateY(0);
		}

		/* Stagger children for a cascading effect */
		.timeline-item:nth-child(1) { transition-delay: 0s; }
		.timeline-item:nth-child(2) { transition-delay: 0.08s; }
		.timeline-item:nth-child(3) { transition-delay: 0.16s; }
		.timeline-item:nth-child(4) { transition-delay: 0.24s; }
		.timeline-item:nth-child(5) { transition-delay: 0.32s; }
		.timeline-item:nth-child(6) { transition-delay: 0.4s; }

		/* Dot pulse animation when visible */
		.timeline-item.is-visible .timeline-dot {
			animation: dotPulse 0.5s ease-out 0.3s;
		}

		@keyframes dotPulse {
			0% { box-shadow: 0 0 0 4px #eff6ff; }
			50% { box-shadow: 0 0 0 8px rgba(59, 130, 246, 0.2); }
			100% { box-shadow: 0 0 0 4px #eff6ff; }
		}

		/* Timeline line grow animation */
		.timeline-line {
			transform-origin: top;
			transition: transform 0.8s cubic-bezier(0.22, 1, 0.36, 1);
		}
		@media only screen and (min-width: 1130px) {
			.utilities-area .logo-section {
				width: auto !important;
			}
		}
	</style>
<link rel='stylesheet' id='vcita-widget-style-css' href='http://acm-local.local/wp-content/plugins/meeting-scheduler-by-vcita/assets/style/widget_v.css?ver=7.0' media='all' />

</head>

<body
	class="posttype_ not_home">
	<header id="header" class="row">
		<nav class="top-bar eyebrow show-for-medium-up" data-topbar data-options="is_hover: false">
			<section class="top-bar-section">
				<div id="skiptocontent"><a href="#SkipTarget">skip to main content</a></div>
							</section>
		</nav>
		<div class="clearfix utilities-area">
			<div class="logo-section">
				<div class="navbar-header show-for-large-up">
					<a class="navbar-brand" href="http://acm-local.local" style="display: flex; align-items: center; text-decoration: none;">
												<img alt="ACM Logo" height="55" class="logo" title="Home" style="margin-top: 8px; margin-bottom: 8px;"
							src="http://acm-local.local/wp-content/themes/acm/img/logo.png" />
					</a>
				</div>
				<div class="navbar-header hide-for-large-up">
					<a href="http://acm-local.local" style="display: flex; align-items: center; text-decoration: none;">
						<img alt="ACM Logo" class="img-responsive hide-for-large-up" title="Home"
							src="http://acm-local.local/wp-content/themes/acm/img/logo.png" style="max-height: 50px; width: auto; float: left; margin-right: 10px;">
					</a>
				</div>
			</div>
			<div id="acm-description" class="column large-5 show-for-large-up">
				<div>
					ACM-W India supporting, celebrating, and advocating for Women in Computing.
				</div>
			</div>
			<div id="ctas-and-search" class="column large-5 medium-6 no-pad-left ctas-and-search">
								<div style="float: right; height: 100%; display: flex; align-items: center;">
					<a href="https://www.linkedin.com/company/acm-w-india/" target="_blank" style="background-color: #005a87; color: #ffffff; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 10px 16px; margin-top: 15px; margin-bottom: 15px; font-family: 'Roboto Condensed', Helvetica, Arial, sans-serif; font-weight: 500; font-size: 14px; transition: background-color 0.2s ease;" onmouseover="this.style.backgroundColor='#004b6b'" onmouseout="this.style.backgroundColor='#005a87'" title="LinkedIn">
						LinkedIn
						<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 1px;"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
					</a>
				</div>
			</div>
		</div>
		<nav class="top-bar main-nav" data-topbar data-options="is_hover: false">
			<ul class="title-area">
				<li class="toggle-topbar menu-icon">
					<a href="/#"><span></span></a>
				</li>
			</ul>
			<section class="top-bar-section">
				<div class="mobile-links">
					<div class="mobile-search">
						<form method="get" id="searchform" action="http://acm-local.local">
							<i class="fa fa-search left"></i>
							<input class="text" type="text" value=" " name="s" id="s" />
							<input type="submit" class="submit button" name="submit"
								value="Search" />
						</form>
					</div>
				</div>
				<div class="menu-container"><ul id="primary-menu" class="nav-menu" style="display:flex; list-style:none; margin:0; padding:0 0 0 15px; align-items:center; height:100%;"><li class="menu-item" style="margin-right: 2rem;"><a href="/" style="color:#fff; font-weight:400; font-family:'Roboto Condensed', Helvetica, Roboto, Arial, sans-serif; font-size:15px; text-transform:uppercase; text-decoration:none;">Home</a></li><li class="menu-item" style="margin-right: 2rem;"><a href="/about/" style="color:#fff; font-weight:400; font-family:'Roboto Condensed', Helvetica, Roboto, Arial, sans-serif; font-size:15px; text-transform:uppercase; text-decoration:none;">About</a></li><li class="menu-item" style="margin-right: 2rem;"><a href="/executive-committee/" style="color:#fff; font-weight:400; font-family:'Roboto Condensed', Helvetica, Roboto, Arial, sans-serif; font-size:15px; text-transform:uppercase; text-decoration:none;">Executive Committee</a></li><li class="menu-item" style="margin-right: 2rem;"><a href="/flagship-events/" style="color:#fff; font-weight:400; font-family:'Roboto Condensed', Helvetica, Roboto, Arial, sans-serif; font-size:15px; text-transform:uppercase; text-decoration:none;">Flagship Events</a></li><li class="menu-item" style="margin-right: 2rem;"><a href="/student-chapters/" style="color:#fff; font-weight:400; font-family:'Roboto Condensed', Helvetica, Roboto, Arial, sans-serif; font-size:15px; text-transform:uppercase; text-decoration:none;">Student Chapters</a></li></ul></div>				<button class="nav__dropdown-toggle">MORE</button>
				<div class="more-list-box"></div>
			</section>
		</nav>
	</header>
	<main id="main" role="main">
<div class="row breadcrumb-container">
	<div class="columns small-12">
		<ul class="breadcrumbs">
			<ul id="crumbs" class="breadcrumbs">
			<li><a href="http://acm-local.local">Home</a></li>
			</ul>
				</ul>
	</div>
</div>
	<div class="banner-container">
		<div class="acm-banner-container" style="background-image: url('');">
			<div class="gradient-wrapper"></div>
			<div class="overlay"></div>
			<div class="row">
				<div class="columns large-12 medium-12 banner-content">
					<p class="banner-heading">
						<small></small>
											</p>
					<p></p>
				</div>
			</div>
		</div>
	</div>
<div id="maincontent" class="row">
	<article class="has-edit-button columns large-12 medium-12 small-12 zone-1" id="SkipTarget" tabindex="-1">
		<h1 class="page-title">Not Found - 404</h1>
		<section>
			<p>Use the search form below to find the page you are looking for.</p>
			<form role="search" method="get" class="search-form" action="http://acm-local.local/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>		</section>
	</article>
</div>
<div class="row">
	<style>
		footer {
			background: #111827 !important; /* Rich Dark Charcoal/Slate */
			border-top: 6px solid #a6bc09 !important; /* Signature Lime line */
			color: #94a3b8 !important;
			padding: 4rem 0 2.5rem 0 !important;
			font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
		}
		.footer-wrapper {
			max-width: 1200px;
			margin: 0 auto;
			padding: 0 1.5rem;
		}
		.footer-main-grid {
			display: grid;
			grid-template-columns: 1.5fr 1fr 1fr;
			gap: 3rem;
			padding-bottom: 3rem;
			border-bottom: 1px solid #1f2937;
		}
		.footer-brand-section {
			display: flex;
			flex-direction: column;
			gap: 1.25rem;
		}
		.footer-logo-row {
			display: flex;
			align-items: center;
			gap: 16px;
		}
		.footer-logo-badge {
			background: #ffffff;
			padding: 8px 16px;
			border-radius: 10px;
			display: inline-flex;
			align-items: center;
			justify-content: center;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
			border: 1px solid #374151;
		}
		.footer-brand-title {
			font-family: 'Outfit', 'Roboto Condensed', sans-serif;
			font-size: 22px;
			font-weight: 700;
			color: #ffffff !important;
			letter-spacing: -0.02em;
			margin: 0;
		}
		.footer-brand-desc {
			font-size: 14px;
			line-height: 1.6;
			color: #94a3b8;
			margin: 0;
			max-width: 380px;
		}
		.footer-nav-section {
			display: flex;
			flex-direction: column;
			align-items: center;
		}
		.footer-section-title {
			font-family: 'Roboto Condensed', sans-serif;
			font-size: 14px;
			font-weight: 700;
			color: #ffffff !important;
			text-transform: uppercase;
			letter-spacing: 0.1em;
			margin-bottom: 1.5rem;
			margin-top: 0;
		}
		.footer-links-list {
			list-style: none;
			margin: 0;
			padding: 0;
			display: flex;
			flex-direction: column;
			gap: 0.4rem;
			align-items: flex-start;
		}
		.footer-inner-col {
			display: flex;
			flex-direction: column;
			align-items: flex-start;
			text-align: left;
		}
		.footer-links-list a {
			color: #94a3b8 !important;
			font-size: 14.5px;
			text-decoration: none !important;
			transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
			display: inline-block;
		}
		.footer-links-list a:hover {
			color: #a6bc09 !important;
			transform: scale(1.05);
		}
		.footer-connect-section {
			display: flex;
			flex-direction: column;
			align-items: flex-end;
		}
		.footer-social-links {
			display: flex;
			gap: 12px;
			list-style: none;
			margin: 0 0 1.5rem 0;
			padding: 0;
		}
		.footer-social-btn {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 42px;
			height: 42px;
			border-radius: 50%;
			background: #1f2937;
			color: #cbd5e1 !important;
			transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
			border: 1px solid #374151;
		}
		.footer-social-btn:hover {
			background: #a6bc09;
			color: #030712 !important;
			transform: translateY(-3px) scale(1.05);
			border-color: #a6bc09;
			box-shadow: 0 6px 15px rgba(166, 188, 9, 0.3);
		}
		.footer-social-btn svg {
			display: block;
		}
		.footer-parent-logo {
			margin-top: 0.5rem;
		}
		.footer-parent-logo img {
			max-height: 55px;
			width: auto;
			opacity: 0.85;
			transition: opacity 0.2s;
		}
		.footer-parent-logo img:hover {
			opacity: 1;
		}
		.footer-bottom {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding-top: 1.5rem;
			font-size: 13px;
			color: #64748b;
		}
		.footer-bottom a {
			color: #64748b !important;
			text-decoration: none !important;
			transition: color 0.2s;
		}
		.footer-bottom a:hover {
			color: #94a3b8 !important;
		}
		@media (max-width: 768px) {
			footer {
				padding: 3rem 0 2rem 0 !important;
			}
			.footer-main-grid {
				grid-template-columns: 1fr;
				gap: 2.5rem;
				text-align: center;
				padding-bottom: 2rem;
			}
			.footer-brand-section, .footer-nav-section, .footer-connect-section {
				align-items: center;
				text-align: center;
			}
			.footer-inner-col {
				align-items: center !important;
				text-align: center !important;
			}
			.footer-logo-row {
				flex-direction: column;
				gap: 10px;
			}
			.footer-brand-desc {
				max-width: 100%;
			}
			.footer-bottom {
				flex-direction: column;
				gap: 1rem;
				text-align: center;
			}
		}
	</style>
	<footer>
		<div class="footer-wrapper">
							<div class="footer-main-grid">
					<!-- Column 1: Brand / ACM-W India Logo -->
					<div class="footer-brand-section">
						<div class="footer-logo-row">
							<div class="footer-logo-badge">
								<img alt="ACM-W India Logo" height="50" style="max-height: 50px; width: auto;" src="http://acm-local.local/wp-content/themes/acm/img/logo.png">
							</div>
							<h3 class="footer-brand-title">ACM-W India</h3>
						</div>
						<p class="footer-brand-desc">
							Supporting, celebrating, and advocating for women in computing across India.
						</p>
					</div>

					<!-- Column 2: Centered Quick Links -->
					<div class="footer-nav-section">
						<div class="footer-inner-col">
							<h4 class="footer-section-title">Quick Links</h4>
							<ul class="footer-links-list">
								<li><a href="http://acm-local.local">Home</a></li>
								<li><a href="http://acm-local.local/about/">About</a></li>
								<li><a href="http://acm-local.local/student-chapters/">Student Chapters</a></li>
								<li><a href="http://acm-local.local/executive-committee/">Executive Committee</a></li>
								<li><a href="http://acm-local.local/flagship-events/">Flagship Events</a></li>
							</ul>
						</div>
					</div>

					<!-- Column 3: Social Links -->
					<div class="footer-connect-section">
						<div class="footer-inner-col">
							<h4 class="footer-section-title">Connect With Us</h4>
							<ul class="footer-social-links">
																			<li>
												<a href="https://www.linkedin.com/company/acm-w-india/" target='_blank' class="footer-social-btn" title="Linkedin">
													<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>												</a>
											</li>
																		</ul>
							
							<!-- Optional ACM Parent Logo -->
													</div>
					</div>
				</div>
				
			<!-- Footer Bottom Copyright Bar -->
			<div class="footer-bottom">
				<div>
					&copy; 2026 ACM-W India. All Rights Reserved.
				</div>
				<div>
					<a href="https://india.acm.org/" target="_blank">ACM India</a>
				</div>
			</div>
		</div>
	</footer>
	<script>
		$(document).ready(function() {
			var wrapper = document.querySelector(".section-nav");
			var nav = priorityNav.init({
				mainNavWrapper: ".section-nav-wrapper",
				breakPoint: 0,
				navDropdownLabel: "MORE"
			});
		});
	</script>
</div>
</main>
</body>
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/acm/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
		<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		<script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */ </script><script id="tec-user-agent-js" src="http://acm-local.local/wp-content/plugins/the-events-calendar/common/build/js/user-agent.js?ver=da75d0bdea6dde3898df"></script>
<script id="acm-main-js" src="http://acm-local.local/wp-content/themes/acm/patterns/static/js/main.js?ver=1779458718"></script>
<script id="acm-script-js-extra">
var screenReaderText = {"expand":"\u003Cspan class=\"screen-reader-text\"\u003Eexpand child menu\u003C/span\u003E","collapse":"\u003Cspan class=\"screen-reader-text\"\u003Ecollapse child menu\u003C/span\u003E"};
//# sourceURL=acm-script-js-extra
</script>
<script id="acm-script-js" src="http://acm-local.local/wp-content/themes/acm/js/acm.js"></script>
<script id="lenis-js-js" src="https://unpkg.com/lenis@1.1.13/dist/lenis.min.js?ver=1.1.13"></script>
<script id="acm-animations-js" src="http://acm-local.local/wp-content/themes/acm/js/animations.js?ver=1.0.0"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"http://acm-local.local/wp-includes/js/wp-emoji-release.min.js?ver=7.0"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=http://acm-local.local/wp-includes/js/wp-emoji-loader.min.js
</script>

</html>
